import re
actual_file = open('couserapy.txt', 'r')
sum = 0
for line in actual_file:
    number = re.findall('[0-9]+', line)
    for number in numbers:
        sum = sum + int(number)

print(sum)