// Select color input
// Select size input

// When size is submitted by the user, call makeGrid()
function makeGrid(event) {

    event.preventDefault();

    const inputHeight = document.querySelector('#inputHeight').value; // User height input
    const inputWidth = document.querySelector('#inputWidth').value;   //User Width input
    const pixelTable = document.querySelector('#pixelCanvas'); // pick canvas of user defined size
    
    while (pixelTable.firstChild) {
        pixelTable.removeChild(pixelTable.firstChild); // removes the default canvas (1px:1px)
    }
           // creating grid from user given input
    for (let height = 0; height < inputHeight; height++) {
        const row = document.createElement('tr');
        for (let width = 0; width < inputWidth; width++) {
            const cell = document.createElement('td');
            cell.addEventListener('click', function () {
                const color = document.querySelector('input#colorPicker').value;// User height input
                cell.style.backgroundColor = color;
            });
            cell.addEventListener('dblclick', function () {
                cell.style.backgroundColor = 'white' ;
            });
   
            row.appendChild(cell); 
        }
        pixelTable.appendChild(row)
    }
}

const form = document.querySelector('form#sizePicker');//returns the first element from form
form.addEventListener('submit', makeGrid); // display canvas grid